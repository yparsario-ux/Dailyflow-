package com.dailyflow.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ScheduleStore {
    private static final String PREF="dailyflow_data";
    private static final String DAYS="days";
    public static final String[] NAMES={"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
    private static final String[][] STARTER={
        {"05:30|Wake up and drink water","06:00|Stretch / workout","06:30|Breakfast and get ready","07:00|School","16:00|Rest and snack","17:00|Workout","18:00|Homework and studying","20:00|Read, pray, prepare for tomorrow","21:30|Sleep"},
        {"05:30|Wake up and morning routine","06:00|Light exercise","06:30|Breakfast and get ready","07:00|School","16:00|Rest","17:00|Cardio or sports","18:00|Homework and review","20:00|Read or learn a skill","21:30|Sleep"},
        {"05:30|Wake up and make bed","06:00|Stretch","06:30|Breakfast and get ready","07:00|School","16:00|Rest and snack","17:00|Strength workout","18:00|Homework and review","20:00|Journal and reflect","21:30|Sleep"},
        {"05:30|Wake up and make bed","06:00|Walk or light exercise","06:30|Breakfast and get ready","07:00|School","16:00|Rest","17:00|Light workout and stretching","18:00|Finish assignments","20:00|Grooming, reading, planning","21:30|Sleep"},
        {"05:30|Wake up and morning routine","06:00|Stretch and move","06:30|Breakfast and get ready","07:00|School","16:00|Rest","17:00|Workout or favorite sport","18:00|Finish schoolwork","20:00|Relax / family time","21:30|Sleep"},
        {"06:30|Wake up and make bed","07:00|Workout, jogging, or sports","08:00|Breakfast and shower","09:00|Help with household chores","10:00|Learn a skill or hobby","12:00|Lunch and rest","14:00|Personal project or study","16:00|Friends, family, or outdoors","21:30|Sleep"},
        {"06:30|Wake up and make bed","07:00|Collect trash and laundry","07:30|Organize clothes, desk, belongings","08:00|Dust surfaces and clean mirrors","08:30|Sweep and mop floor","09:00|Change bedsheets and pillowcases","09:30|Shower and breakfast","10:00|Prepare school supplies and clothes","12:00|Lunch and rest","14:00|Review lessons and plan week","16:00|Relax / family time","19:00|Dinner and prepare for Monday","21:30|Sleep"}
    };

    private final SharedPreferences prefs;
    public ScheduleStore(Context c) {
        prefs=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        if(!prefs.contains(DAYS)) seed();
    }
    private String key(int day){return "day_"+day;}
    private void seed(){
        SharedPreferences.Editor e=prefs.edit();
        for(int d=0;d<7;d++){
            JSONArray arr=new JSONArray(); int i=0;
            for(String line:STARTER[d]){
                String[] p=line.split("\\|",2);
                JSONObject o=new JSONObject();
                try { o.put("id","seed_"+d+"_"+(i++)); o.put("time",p[0]); o.put("title",p[1]); o.put("note",""); o.put("alarm",false); o.put("done",false); arr.put(o); } catch(Exception ignored){}
            }
            e.putString(key(d),arr.toString());
        }
        e.apply();
    }
    public List<TaskItem> get(int day){
        List<TaskItem> out=new ArrayList<>();
        try {
            JSONArray a=new JSONArray(prefs.getString(key(day),"[]"));
            for(int i=0;i<a.length();i++) out.add(TaskItem.fromJson(a.getJSONObject(i)));
        } catch(Exception ignored){}
        Collections.sort(out, Comparator.comparing(t->t.time));
        return out;
    }
    public void save(int day,List<TaskItem> tasks){
        JSONArray a=new JSONArray();
        try { for(TaskItem t:tasks)a.put(t.toJson()); } catch(Exception ignored){}
        prefs.edit().putString(key(day),a.toString()).apply();
    }
    public void add(int day,TaskItem task){List<TaskItem> l=get(day);l.add(task);save(day,l);}
    public void delete(int day,String id){List<TaskItem> l=get(day);for(int i=l.size()-1;i>=0;i--)if(l.get(i).id.equals(id))l.remove(i);save(day,l);}
    public void update(int day,TaskItem item){List<TaskItem> l=get(day);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(item.id)){l.set(i,item);break;}save(day,l);}
}
