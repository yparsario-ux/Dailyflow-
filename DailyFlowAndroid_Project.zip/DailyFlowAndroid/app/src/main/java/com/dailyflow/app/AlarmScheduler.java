package com.dailyflow.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Calendar;
import java.util.List;

public class AlarmScheduler {
    public static void schedule(Context c,int day,TaskItem task) {
        cancel(c,task.id);
        if(!task.alarm)return;
        String[] p=task.time.split(":");
        int hour=Integer.parseInt(p[0]), minute=Integer.parseInt(p[1]);
        Calendar now=Calendar.getInstance();
        int today=(now.get(Calendar.DAY_OF_WEEK)+5)%7; // Monday=0
        Calendar at=Calendar.getInstance();
        at.set(Calendar.HOUR_OF_DAY,hour);at.set(Calendar.MINUTE,minute);at.set(Calendar.SECOND,0);at.set(Calendar.MILLISECOND,0);
        int delta=(day-today+7)%7;
        if(delta==0 && at.getTimeInMillis()<=now.getTimeInMillis())delta=7;
        at.add(Calendar.DAY_OF_YEAR,delta);
        Intent i=new Intent(c,AlarmReceiver.class);
        i.putExtra("title",task.title);i.putExtra("id",task.id);i.putExtra("day",day);i.putExtra("time",task.time);
        PendingIntent pi=PendingIntent.getBroadcast(c,task.id.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am!=null){
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at.getTimeInMillis(),pi);
            } else if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at.getTimeInMillis(),pi);
            } else am.setExact(AlarmManager.RTC_WAKEUP,at.getTimeInMillis(),pi);
        }
    }
    public static void cancel(Context c,String id){
        Intent i=new Intent(c,AlarmReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),i,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
        if(pi!=null){AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am!=null)am.cancel(pi);pi.cancel();}
    }
    public static void rescheduleAll(Context c){
        ScheduleStore s=new ScheduleStore(c);
        for(int d=0;d<7;d++) for(TaskItem t:s.get(d)) schedule(c,d,t);
    }
}
