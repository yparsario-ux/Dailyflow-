package com.dailyflow.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends Activity {
    private ScheduleStore store;
    private int selectedDay;
    private LinearLayout root, listBox, dayBar;
    private TextView heading, alarmSummary;
    private final int black=Color.rgb(20,20,20), gray=Color.rgb(110,110,110), light=Color.rgb(244,244,245);

    @Override public void onCreate(Bundle b){
        super.onCreate(b); getWindow().setStatusBarColor(black); getWindow().setNavigationBarColor(black);
        store=new ScheduleStore(this);
        java.util.Calendar c=java.util.Calendar.getInstance();
        selectedDay=(c.get(java.util.Calendar.DAY_OF_WEEK)+5)%7;
        buildUi();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},21);
    }
    private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(black);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void pad(View v,int n){v.setPadding(dp(n),dp(n),dp(n),dp(n));}
    private GradientDrawableCompat bg(int color,int radius){return new GradientDrawableCompat(color,dp(radius));}
    private void buildUi(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        root=vertical();root.setBackgroundColor(light);scroll.addView(root);setContentView(scroll);
        LinearLayout hero=vertical();hero.setBackgroundColor(black);hero.setPadding(dp(20),dp(24),dp(20),dp(22));
        TextView eyebrow=text("YOUR PERSONAL ROUTINE",12,true);eyebrow.setTextColor(Color.LTGRAY);
        TextView title=text("DailyFlow",30,true);title.setTextColor(Color.WHITE);
        TextView desc=text("Plan your day. Build your habits. Stay on track.",14,false);desc.setTextColor(Color.LTGRAY);
        hero.addView(eyebrow);hero.addView(title);hero.addView(desc);root.addView(hero);
        LinearLayout body=vertical();body.setPadding(dp(14),dp(14),dp(14),dp(28));root.addView(body);
        TextView date=text(new java.text.SimpleDateFormat("EEEE, MMM d",java.util.Locale.getDefault()).format(new java.util.Date()),13,false);date.setTextColor(gray);body.addView(date);
        heading=text("Monday schedule",22,true);LinearLayout head=horizontal();head.addView(heading,new LinearLayout.LayoutParams(0,-2,1));
        Button add=button("+ Add task",true);add.setOnClickListener(v->editTask(null));head.addView(add);body.addView(head);
        dayBar=horizontal();dayBar.setGravity(Gravity.CENTER);dayBar.setPadding(0,dp(10),0,dp(12));body.addView(dayBar);
        LinearLayout card=vertical();card.setBackground(bg(Color.WHITE,16));pad(card,14);body.addView(card);
        card.addView(text("Today's schedule",18,true));
        TextView hint=text("Tap a task to mark it done. Edit anything.",12,false);hint.setTextColor(gray);card.addView(hint);
        listBox=vertical();LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(8);card.addView(listBox,lp);
        LinearLayout alarmCard=vertical();alarmCard.setBackground(bg(Color.WHITE,16));pad(alarmCard,14);LinearLayout.LayoutParams acp=new LinearLayout.LayoutParams(-1,-2);acp.topMargin=dp(14);body.addView(alarmCard,acp);
        alarmCard.addView(text("Alarm center",18,true));alarmSummary=text("No alarms set");alarmSummary.setTextSize(14);alarmSummary.setTextColor(gray);alarmCard.addView(alarmSummary);
        Button test=button("Test alarm sound",false);test.setOnClickListener(v->{android.media.ToneGenerator tg=new android.media.ToneGenerator(android.media.AudioManager.STREAM_ALARM,90);tg.startTone(android.media.ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD,1200);new AlertDialog.Builder(this).setTitle("Test alarm").setMessage("DailyFlow alarm sound test.").setPositiveButton("OK",null).show();});alarmCard.addView(test);
        LinearLayout starter=vertical();starter.setBackground(bg(Color.WHITE,16));pad(starter,14);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(14);body.addView(starter,sp);
        starter.addView(text("Quick routine ideas",18,true));
        Button school=button("＋ Add school-day routine",false);school.setOnClickListener(v->addStarter(false));starter.addView(school);
        Button sunday=button("＋ Add room-cleaning routine",false);sunday.setOnClickListener(v->addStarter(true));starter.addView(sunday);
        TextView foot=text("Saved on this phone • Keep alarms enabled in Android settings",12,false);foot.setTextColor(gray);foot.setGravity(Gravity.CENTER);LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,-2);fp.topMargin=dp(16);body.addView(foot,fp);
        render();
    }
    private Button button(String label,boolean primary){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(13);b.setTextColor(primary?Color.WHITE:black);b.setBackground(bg(primary?black:Color.rgb(235,235,235),10));return b;}
    private void render(){
        heading.setText(ScheduleStore.NAMES[selectedDay]+" schedule");dayBar.removeAllViews();
        for(int d=0;d<7;d++){final int day=d;TextView b=text(ScheduleStore.NAMES[d].substring(0,3),12,true);b.setGravity(Gravity.CENTER);b.setPadding(dp(4),dp(10),dp(4),dp(10));b.setBackground(bg(d==selectedDay?black:Color.WHITE,9));b.setTextColor(d==selectedDay?Color.WHITE:black);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(dp(2),0,dp(2),0);dayBar.addView(b,p);b.setOnClickListener(v->{selectedDay=day;render();});}
        listBox.removeAllViews();List<TaskItem> tasks=store.get(selectedDay);
        if(tasks.isEmpty()){listBox.addView(text("No tasks yet. Add your first task.",14,false));}
        int alarms=0;
        for(TaskItem t:tasks){
            if(t.alarm)alarms++;
            LinearLayout row=horizontal();row.setPadding(0,dp(9),0,dp(9));
            TextView time=text(format(t.time),12,true);time.setWidth(dp(65));row.addView(time);
            LinearLayout mid=vertical();TextView name=text(t.title,14,true);if(t.done){name.setPaintFlags(name.getPaintFlags()|android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);name.setTextColor(gray);}mid.addView(name);
            if(!t.note.isEmpty()){TextView note=text(t.note,11,false);note.setTextColor(gray);mid.addView(note);}
            TextView al=text(t.alarm?"🔔 Alarm on":"",10,false);al.setTextColor(gray);mid.addView(al);
            row.addView(mid,new LinearLayout.LayoutParams(0,-2,1));
            LinearLayout actions=vertical();Button done=mini(t.done?"Undo":"Done");done.setOnClickListener(v->{t.done=!t.done;store.update(selectedDay,t);render();});actions.addView(done);
            Button edit=mini("Edit");edit.setOnClickListener(v->editTask(t));actions.addView(edit);
            Button del=mini("Delete");del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Delete this task?").setNegativeButton("Cancel",null).setPositiveButton("Delete",(a,b)->{AlarmScheduler.cancel(this,t.id);store.delete(selectedDay,t.id);render();}).show());actions.addView(del);
            row.addView(actions);listBox.addView(row);
            View line=new View(this);line.setBackgroundColor(0xffeeeeee);listBox.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        }
        alarmSummary.setText(alarms+" alarm"+(alarms==1?"":"s")+" enabled for "+ScheduleStore.NAMES[selectedDay]+". Alarms repeat weekly.");
    }
    private Button mini(String s){Button b=button(s,false);b.setTextSize(10);b.setPadding(dp(4),0,dp(4),0);return b;}
    private String format(String t){try{String[] p=t.split(":");int h=Integer.parseInt(p[0]),m=Integer.parseInt(p[1]);return ((h%12==0)?12:h%12)+":"+String.format(java.util.Locale.getDefault(),"%02d",m)+" "+(h>=12?"PM":"AM");}catch(Exception e){return t;}}
    private void editTask(TaskItem existing){
        LinearLayout form=vertical();form.setPadding(dp(8),dp(4),dp(8),dp(4));
        EditText title=new EditText(this);title.setSingleLine(true);title.setHint("Task name");title.setText(existing==null?"":existing.title);form.addView(title);
        EditText note=new EditText(this);note.setSingleLine(true);note.setHint("Notes (optional)");note.setText(existing==null?"":existing.note);form.addView(note);
        final String[] time={existing==null?"17:00":existing.time};
        Button timeButton=button("Time: "+format(time[0]),false);form.addView(timeButton);
        timeButton.setOnClickListener(v->{String[] p=time[0].split(":");new TimePickerDialog(this,(view,h,m)->{time[0]=String.format(java.util.Locale.US,"%02d:%02d",h,m);timeButton.setText("Time: "+format(time[0]));},Integer.parseInt(p[0]),Integer.parseInt(p[1]),false).show();});
        CheckBox alarm=new CheckBox(this);alarm.setText("Set alarm for this task");alarm.setChecked(existing!=null&&existing.alarm);form.addView(alarm);
        new AlertDialog.Builder(this).setTitle(existing==null?"Add task":"Edit task").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",(dialog,which)->{
            String name=title.getText().toString().trim();if(name.isEmpty()){Toast.makeText(this,"Enter a task name",Toast.LENGTH_SHORT).show();return;}
            TaskItem t=new TaskItem(existing==null?UUID.randomUUID().toString():existing.id,time[0],name,note.getText().toString().trim(),alarm.isChecked(),existing!=null&&existing.done);
            if(existing==null)store.add(selectedDay,t);else store.update(selectedDay,t);
            AlarmScheduler.schedule(this,selectedDay,t);render();
        }).show();
    }
    private void addStarter(boolean cleaning){
        String[][] items=cleaning?new String[][]{{"07:00","Collect trash and laundry"},{"07:30","Organize clothes and desk"},{"08:00","Dust surfaces and mirrors"},{"08:30","Sweep and mop floor"},{"09:00","Change bedsheets"}}:
        new String[][]{{"05:30","Wake up and drink water"},{"06:00","Stretch"},{"06:30","Breakfast and get ready"},{"07:00","School"},{"16:00","Rest and snack"},{"18:00","Homework and studying"},{"21:30","Sleep"}};
        for(String[] x:items)store.add(selectedDay,new TaskItem(UUID.randomUUID().toString(),x[0],x[1],cleaning?"Sunday room-cleaning routine":"School-day routine",false,false));
        render();Toast.makeText(this,"Routine added",Toast.LENGTH_SHORT).show();
    }
    static class GradientDrawableCompat extends android.graphics.drawable.GradientDrawable{
        GradientDrawableCompat(int color,int radius){setColor(color);setCornerRadius(radius);}
    }
}
