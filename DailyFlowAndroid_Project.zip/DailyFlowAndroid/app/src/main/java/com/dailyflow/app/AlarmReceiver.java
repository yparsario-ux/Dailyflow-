package com.dailyflow.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {
    private static final String CHANNEL="dailyflow_alarms";
    @Override public void onReceive(Context context,Intent intent){
        String title=intent.getStringExtra("title"); if(title==null)title="Scheduled task";
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(CHANNEL,"DailyFlow alarms",NotificationManager.IMPORTANCE_HIGH));
        Intent open=new Intent(context,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(context,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(context,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("⏰ DailyFlow alarm")
            .setContentText(title).setStyle(new NotificationCompat.BigTextStyle().bigText("It's time for: "+title))
            .setPriority(NotificationCompat.PRIORITY_MAX).setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true).setContentIntent(pi);
        nm.notify((int)(System.currentTimeMillis()%Integer.MAX_VALUE),b.build());
        try { ToneGenerator tone=new ToneGenerator(AudioManager.STREAM_ALARM,90); tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD,1800); } catch(Exception ignored){}
        int day=intent.getIntExtra("day",-1);
        String time=intent.getStringExtra("time");
        String id=intent.getStringExtra("id");
        if(day>=0&&time!=null&&id!=null){
            for(TaskItem t:new ScheduleStore(context).get(day))if(t.id.equals(id)){AlarmScheduler.schedule(context,day,t);break;}
        }
    }
}
