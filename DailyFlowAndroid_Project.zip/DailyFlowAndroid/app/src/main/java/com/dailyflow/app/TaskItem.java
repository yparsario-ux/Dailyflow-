package com.dailyflow.app;

import org.json.JSONException;
import org.json.JSONObject;

public class TaskItem {
    public String id, time, title, note;
    public boolean alarm, done;

    public TaskItem(String id, String time, String title, String note, boolean alarm, boolean done) {
        this.id=id; this.time=time; this.title=title; this.note=note; this.alarm=alarm; this.done=done;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o=new JSONObject();
        o.put("id",id); o.put("time",time); o.put("title",title); o.put("note",note);
        o.put("alarm",alarm); o.put("done",done); return o;
    }

    public static TaskItem fromJson(JSONObject o) throws JSONException {
        return new TaskItem(o.getString("id"),o.getString("time"),o.getString("title"),
            o.optString("note",""),o.optBoolean("alarm",false),o.optBoolean("done",false));
    }
}
