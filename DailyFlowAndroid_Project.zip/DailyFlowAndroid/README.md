# DailyFlow Android App

A native Android starter project for a customizable daily schedule and recurring alarms.

## Build an APK
1. Install Android Studio on a computer.
2. Open this `DailyFlowAndroid` folder in Android Studio.
3. Let Gradle sync and install any requested Android SDK components (compile SDK 35).
4. Choose **Build > Build APK(s)**.
5. Find the APK under `app/build/outputs/apk/debug/app-debug.apk`.

## Alarm notes
- Tasks can have alarms enabled individually; alarms repeat weekly on the selected weekday.
- Android 13+ may ask for notification permission.
- On Android 12+, exact-alarm access may need to be enabled in **Settings > Apps > Special app access > Alarms & reminders**. If exact access is not granted, the app falls back to an inexact alarm.
- Device manufacturers may restrict background alarms. Test the alarms on the target phone.
- Data is stored locally in the app's SharedPreferences. Uninstalling the app clears its data.

## Features
- Monday through Sunday tabs
- Add, edit, delete, and complete tasks
- Optional alarm per task
- Starter school-day and Sunday room-cleaning routines
- Weekly alarm rescheduling after reboot
